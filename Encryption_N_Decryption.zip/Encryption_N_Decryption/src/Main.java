
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MSPAK
 */
public class Main {
    public static void main(String[] args){
        Scanner input=new Scanner (System.in);
        int choice;
        while(true){
            System.out.print("\n1.Encryption\n2.Decryption\n3.Exit\nEnter your choice: ");
            choice=input.nextInt();
            if(choice==3){
                System.out.println("Exiting");
                break;
            }
            else if(choice==2){
                Decryption_V2 a=new Decryption_V2();
                a.Decrpytion();
            }
            else if(choice ==1){
                Encryption a=new Encryption();
                a.Encryption();
            }
            else{
                System.out.println("Sorry Wrong Entry");
            }
            
        }
    }
    
}
