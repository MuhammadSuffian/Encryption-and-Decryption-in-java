
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MSPAK
 */
public class Encryption {
     public void Encryption(){
       String msg,cipher="";
       int key=0,converter=0;
       while (key < 100 || key > 600) {
       key = (int)(Math.random() * 501) + 100; // Generates a random number between 100 and 600
       //System.out.println(key);
        }
       Scanner input=new Scanner(System.in);
       System.out.print("Enter your Message: ");
       msg=input.nextLine();
      // System.out.println("Message: "+msg);
      for(int i=0;i<msg.length();i++){
        converter=msg.charAt(i)+key;
        cipher=cipher+converter;
      }
        System.out.println("Cipher: "+cipher);
         System.out.println("Key: "+key);
        
    }
    
    
}
