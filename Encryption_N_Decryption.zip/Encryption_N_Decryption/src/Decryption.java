
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MSPAK
 */
public class Decryption {
    public  void Decryption(){
        String msg="",cipher="";
        long key=0;
        String temp="";
        char temp1;
        long temp2=0;
        Scanner input=new Scanner(System.in);
        System.out.print("Enter the cipher Text: ");
        cipher=input.next();
        
        System.out.print("Enter the key: ");
        key=input.nextInt();

        for(int i=0;i<cipher.length();i=i+3){
            temp="";
            temp=temp+cipher.charAt(i);
            temp=temp+cipher.charAt(i+1)+"";
            temp=temp+cipher.charAt(i+2)+"";
            
            temp2=Integer.valueOf(temp)-key;
            
            temp1=(char)(temp2);
            msg=msg+temp1;
        }
          System.out.println("Your Decrypted message: "+msg+"\n");
    }
    
}
